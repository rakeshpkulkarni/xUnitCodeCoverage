﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;

namespace FIS.IP.Customer.Core.UnitTest
{
	public static class Constants
	{
		public static string API_RESPONSE_JSON_DIRECTORY_Cust = (Path.GetDirectoryName(Assembly‌​.GetExecutingAssembly‌​().Location) + @"\..\..\..\ControllerResponseJsons\");
		public static string API_REQUEST_JSON_DIRECTORY_Cust = (Path.GetDirectoryName(Assembly‌​.GetExecutingAssembly‌​().Location) + @"\..\..\..\ControllerRequestJsons\");

		public static string API_RESPONSE_JSON_DIRECTORY_Vendor = (Path.GetDirectoryName(Assembly‌​.GetExecutingAssembly‌​().Location) + @"\..\..\..\ControllerResponseJsons\");
		public static string API_REQUEST_JSON_DIRECTORY_Vendor = (Path.GetDirectoryName(Assembly‌​.GetExecutingAssembly‌​().Location) + @"\..\..\..\ControllerRequestJsons\");

		public static string VendorServiceBaseURL = "https://localhost:44351/";
		public static string BaseURL = "https://localhost:44320/";

	}
}
