﻿using Newtonsoft.Json;
using System.IO;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Text;

namespace FIS.IP.Customer.Core.UnitTest.Helper.DataHelper
{
	public static class RequestHelper
	{
		public static HttpContent GetRequestObject(string expectedResponseJsonName)
		{
			//string localFilePath = System.IO.Path.GetFullPath(Constants.API_REQUEST_JSON_DIRECTORY + expectedResponseJsonName);
			string json = null;

			StreamReader sr = File.OpenText(expectedResponseJsonName);
			json = sr.ReadToEnd();
			dynamic array = JsonConvert.DeserializeObject(json);
			var HttpContent = new ObjectContent(array.GetType(),
														array,
														new JsonMediaTypeFormatter());
			sr.Close();
			return HttpContent;
		}

		/// <summary>
		/// This method is used for creating Request object model for POST API requests in an efficient way.
		/// It can be used as GetRequestObject is being used.
		/// </summary>
		/// <param name="requestJSONFilePath">File Path to create JSON request object</param>
		/// <returns>Content Object which can be used for sending Post request.</returns>
		public static StringContent MakeRequestObject(string requestJSONFilePath)
		{
			if (!File.Exists(requestJSONFilePath))
			{
				return new StringContent("", Encoding.UTF8, "application/json");
			}

			return new StringContent(File.ReadAllText(requestJSONFilePath), Encoding.UTF8, "application/json");
		}
	}
}