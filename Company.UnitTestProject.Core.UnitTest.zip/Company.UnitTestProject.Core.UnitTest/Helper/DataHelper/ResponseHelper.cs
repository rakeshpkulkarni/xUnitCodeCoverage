﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace FIS.IP.Customer.Core.UnitTest.Helper.DataHelper
{
	public static class ResponseHelper
	{
		public static bool CompareResponseToJson(string responseJson, string expectedResponseJsonName)
		{
			JObject response = (JObject)JsonConvert.DeserializeObject(responseJson);

			//string localFilePath = System.IO.Path.GetFullPath(Constants.API_RESPONSE_JSON_DIRECTORY + expectedResponseJsonName);
			////To write the frmated code in expeccted json file
			//string json1 = JsonConvert.SerializeObject(response, Formatting.Indented);
			//File.WriteAllText(localFilePath, json1);

			StreamReader sr = File.OpenText(expectedResponseJsonName);
			string json = sr.ReadToEnd();
			JObject expectedResponseJson = (JObject)JsonConvert.DeserializeObject(json);
			sr.Close();

			return JToken.DeepEquals(response, expectedResponseJson);
		}
		public static bool CompareJSONArrayResponse(string responseJsonArray, string expectedResponseJsonArrayFile)
		{
			JArray responseArr = (JArray)JsonConvert.DeserializeObject(responseJsonArray);
			//string localFilePath = System.IO.Path.GetFullPath(expectedResponseJsonArrayFile);
			////To write the frmated code in expeccted json file
			//string json1 = JsonConvert.SerializeObject(responseArr, Formatting.Indented);
			//File.WriteAllText(localFilePath, json1);
			StreamReader sr = File.OpenText(expectedResponseJsonArrayFile);
			string jsonArrayFromFile = sr.ReadToEnd();
			JArray expectedArr = (JArray)JsonConvert.DeserializeObject(jsonArrayFromFile);
			sr.Close();
			bool eachJObjectCompared;
			if (responseArr.Count != expectedArr.Count)
			{
				eachJObjectCompared = false;
			}
			else
			{
				eachJObjectCompared = true;
				for (int counter = 0; counter < responseArr.Count; counter++)
				{
					if (!JToken.DeepEquals(responseArr[counter], expectedArr[counter]))
					{
						eachJObjectCompared = false;
						break;
					}
				}
			}
			return eachJObjectCompared;
		}
	}
}
